<?php
   header('location:../logView/login.php');
?>